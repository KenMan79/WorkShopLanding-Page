# notify
A simple and easy jQuery plugin for Alert Notification

##DEMO
[http://yjseo29.github.io/notify/](http://yjseo29.github.io/notify/)
